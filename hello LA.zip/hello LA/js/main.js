
$(function(){
	 //获取每个div的高度；
	 var $h_arr = [];
	 $("body>div").each(function(index,ele){    
		   $h_arr.push($(this).offset().top);
	   });
	
	    //图标变大函数；
		function toBig(index){
           	     $(this).children("img").attr("src","./images/nav/nav_bg0"+ (index+2) +"H.png");
		     };
		//图标变小函数
		function toSmall(index){
				$(this).children("img").attr("src","./images/nav/nav_bg0"+ (index+2) +".png");
		   };

	     //点击hello_logo跳到页首；
	   $(".hello_logo").click(function(){
	   	   $(window).scrollTop(0);
	   });
      
       //左侧导航点击效果
	   $(".navList>li").each(function(index,ele){
	   	var $this = $(this);
	   	 $this.hover(function(){toBig.call($this,index)},
	   	 	function(){toSmall.call($this,index)}
	   	 	);
		 $this.click(function(){
		 	$this.unbind('mouseleave');
           $(window).scrollTop($h_arr[index+2]-70);
		 });		
	  });
   
	  // 滚动页面时导航图标随之变化
	   $(window).scroll(function(){   	 
	   	  var $curST = $(window).scrollTop(); 
     	  var $idx = -1;
	   	  for(var i=$h_arr.length-1;i>0;i--){
	   	  	     if($curST>=($h_arr[i]-70) && i>1){
                     $idx = i-2;
                     break;
	   	  	     }
	   	  }  	

	   	  //所有图标变小
           $(".navList>li").each(function(index,ele){
               toSmall.call($(this),index);
           });
          
          //当前图标变大；
          if($idx!==-1){
          	 toBig.call($(".navList>li:eq("+ $idx + ")"),$idx);
          }
	   }); 

	   //goWhere_box点击前后按钮，切换图片；
	   var $show_idx = $("#lospic ul li").index();
	   $("#nextbtn").click(function(){
	   	  if($show_idx==3) $show_idx = 0;
	   	   $("#lospic ul>li:eq(" + $show_idx +")").css('display','none');
           $show_idx++;
           $("#lospic ul>li:eq(" + $show_idx +")").css('display','block');
	   });

	   $("#nextbtn").mouseenter(
             function(){
             	$(this).css('background-position','100% 100%');
             });
       $("#nextbtn").mouseleave(
         	function(){
             	$(this).css('background-position','100% 0');
             });
         	     
	    $("#prebtn").click(function(){
	   	  if($show_idx==0) $show_idx = 3;
	   	   $("#lospic ul>li:eq(" + $show_idx +")").css('display','none');
           $show_idx--;
           $("#lospic ul>li:eq(" + $show_idx +")").css('display','block');
	    });
             $("#prebtn").mouseenter(function(){
             	$(this).css('background-position','0 0');
             });
             $("#prebtn").mouseleave(function(){
             	$(this).css('background-position','0 100%');
             });

         //给wel_box intro_nav 增加滚动效果
         var wel_idx = 0;
          setInterval(function(){ 
              $("#wel_box .intro_list .scroll_pic li:eq(" + wel_idx + ")").css('display','none');
              $("#wel_box #scroll_btn li:eq(" + wel_idx +")").css('background-position','-19px 0');
               wel_idx ++;
              if(wel_idx>2) wel_idx = 0;
              $("#wel_box .intro_list .scroll_pic li:eq(" + wel_idx + ")").css('display','block');
              $("#wel_box #scroll_btn li:eq(" + wel_idx +")").css('background-position','0 0');
          },3000)    
	    
	    //给exp_box增加定时滚动效果
	     var scr_idx = 0;
	     setInterval(function(){
           $("#exp_box>ul:eq(" + scr_idx + ")").css('display','none');
           $("#exp_box #scroll_btn li:eq(" + scr_idx + ")").css('background-position','-19px 0');
           scr_idx++;
           if(scr_idx >3) scr_idx = 0;
           $("#exp_box>ul:eq(" + scr_idx + ")").css('display','block');
           $("#exp_box #scroll_btn li:eq(" + scr_idx + ")").css('background-position','0 0');
	     },3000);
          

	     // function scroll(scroll_pic,scroll_btn){
      //      $('"#' + scroll_pic +":eq(" + scr_idx + ")").css('display','none');
      //      $('"#'+ scroll_btn +"li:eq(" + scr_idx + ")").css('background-position','-20px 0');
      //       scr_idx++;
      //      if(scr_idx >3) scr_idx = 0;
      //      $('"#' + scroll_pic + ":eq(" + ul_idx + ")").css('display','block');
      //      $('"#'+ scroll_btn +"li:eq(" + ul_idx + ")").css('background-position','0 0');
	     // }
      
})



